EKRAN SÜRESİ TAKİP PROGRAMI
=========================

Bu program, bilgisayarınızda hangi uygulamaları ne kadar süre kullandığınızı takip etmenizi sağlar.

Kurulum:
--------
1. Program kurulum gerektirmez. Sadece "Ekran_Suresi_Takip.exe" dosyasını çalıştırmanız yeterlidir.
2. İlk çalıştırmada Windows Güvenlik Duvarı uyarı verebilir, "İzin Ver" seçeneğini seçiniz.

Kullanım:
---------
1. Program başlatıldığında otomatik olarak sistem tepsisinde (sağ alt köşede) çalışmaya başlar.
2. Ana pencereyi görmek için sistem tepsisindeki program ikonuna tıklayın.
3. Program üç sekme içerir:
   - Anlık Takip: Günlük uygulama kullanım sürelerini gösterir
   - İstatistikler: Genel kullanım istatistiklerini gösterir
   - Günlük İstatistik: Seçilen güne ait detaylı istatistikleri gösterir

4. Uygulamaları kategorilere ayırabilir ve sağ tıklayarak kategori değiştirebilirsiniz.
5. Tema değiştirme butonu ile koyu/açık tema arasında geçiş yapabilirsiniz.

Önemli Notlar:
-------------
- Program otomatik olarak verileri kaydeder.
- Veriler "ekran_suresi_takip.csv" dosyasında saklanır.
- Kategori ayarları "kategoriler.json" dosyasında saklanır.
- Bu dosyaları silmemeye özen gösterin.

İyi kullanımlar! 